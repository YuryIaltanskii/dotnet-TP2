﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Calcular_Area_Perimetro
{
    interface ICalcular
    {
        void CalcularPerimetro();
        void CalcularArea();
    }
}
