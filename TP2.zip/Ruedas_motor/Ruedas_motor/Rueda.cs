﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ruedas_motor
{
    public class Rueda : IRueda
    {
        public double Diametro
        {
            get
            {
                throw new NotImplementedException();
            }

            set
            {
                throw new NotImplementedException();
            }
        }

        public void frenarRueda()
        {
            throw new NotImplementedException();
        }

        public void iniciarRueda()
        {
            throw new NotImplementedException();
        }
    }
}
