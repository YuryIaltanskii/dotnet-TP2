﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ruedas_motor
{
    public class Motor : IMotor
    {
        public double Cilindrada
        {
            get
            {
                throw new NotImplementedException();
            }

            set
            {
                throw new NotImplementedException();
            }
        }

        public void frenarMotor()
        {
            throw new NotImplementedException();
        }

        public void iniciarMotor()
        {
            throw new NotImplementedException();
        }
    }
}
